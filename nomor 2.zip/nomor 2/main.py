# main.py

from transportasi.kendaraan import ManajemenKendaraan
from transportasi.rute import ManajemenRute
from transportasi.biaya import hitung_biaya

# Inisialisasi manajemen kendaraan dan rute
manajemen_kendaraan = ManajemenKendaraan()
manajemen_rute = ManajemenRute()

# Menambahkan beberapa kendaraan
manajemen_kendaraan.tambah_kendaraan("Toyota", "Avanza", 2020, "Mobil")
manajemen_kendaraan.tambah_kendaraan("Honda", "CBR", 2022, "Motor")

# Menambahkan beberapa rute perjalanan
manajemen_rute.tambah_rute("Jakarta", "Bandung", 150)
manajemen_rute.tambah_rute("Surabaya", "Malang", 100)

# Menampilkan kendaraan
print("Daftar Kendaraan:")
manajemen_kendaraan.tampilkan_kendaraan()

# Menampilkan rute perjalanan
print("\nDaftar Rute Perjalanan:")
manajemen_rute.tampilkan_rute()

# Menghitung dan menampilkan biaya perjalanan
print("\nBiaya Perjalanan:")
for kendaraan in manajemen_kendaraan.kendaraan_list:
    for rute in manajemen_rute.rute_list:
        biaya = hitung_biaya(kendaraan.tipe, rute.jarak)
        print(f"Biaya perjalanan {kendaraan.merek} {kendaraan.model} dari {rute.asal} ke {rute.tujuan}: Rp {biaya}")